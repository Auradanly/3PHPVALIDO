<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    
    <title>Resultado do Cálculo da Densidade</title>
</head>
<body>
    <section>
          <main class="corpo">
        <div class="container">
            <div class="form-container">
               
                <h2>Densidade</h2>
              
<?php
// Verifica se os valores de massa e volume foram enviados via método POST
if(isset($_POST['massa']) && isset($_POST['volume'])) {
    // Obtém os valores de massa e volume do formulário
    $massa = $_POST['massa'];
    $volume = $_POST['volume'];

    // Calcula a densidade
    $densidade = $massa / $volume;

    // Exibe o resultado

    echo "<p>Massa: $massa g</p>";
    echo "<p>Volume: $volume mL</p>";
    echo "<p>Densidade: $densidade g/mL</p>";
} else {
    // Se os valores não foram enviados corretamente, exibe uma mensagem de erro
    echo "<h1>Erro: Valores de massa e/ou volume não foram enviados corretamente.</h1>";
}
?>
<button type="button" id="clearBtn"><a href="../../PRINCIPAL/index.html">Voltar</a></button>
    </div></div>
    </section>

</body>
</html>
