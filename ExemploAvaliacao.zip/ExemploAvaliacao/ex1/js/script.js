document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('form');
    const clearBtn = document.getElementById('clearBtn');

    form.addEventListener('submit', function(event) {
        const username = document.getElementById('username');
        const sobrenome = document.getElementById('sobrenome');
        const nrepeticoes = document.getElementById('nrepeticoes');

        if (username.value.length > 60 || sobrenome.value.length > 60 || isNaN(nrepeticoes.value) || nrepeticoes.value === '') {
            alert('Por favor, preencha os campos corretamente.');
            event.preventDefault();
        }
    });

    clearBtn.addEventListener('click', function() {
        document.getElementById('form').reset();
    });
});
