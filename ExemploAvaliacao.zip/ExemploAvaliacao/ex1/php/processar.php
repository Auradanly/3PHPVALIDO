<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>processar</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <section>
          <main class="corpo">
        <div class="container">
            <div class="form-container">
               
                <h2>Repetições- Nome</h2>
                <button type="button" id="clearBtn"><a href="../../PRINCIPAL/index.html">Voltar</a></button>
    
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = $_POST["username"];
        $sobrenome = $_POST["sobrenome"];
        $nrepeticoes = intval($_POST["nrepeticoes"]);

        echo "<table border='1'>";
        for ($i = 1; $i <= $nrepeticoes; $i++) {
            echo "<tr><td>{$i}</td><td>{$username}</td><td>{$sobrenome}</td></tr>";
        }
        echo "</table>";
        exit();
    }
    ?>
 
    </div></div>
    </section>
</body>

</html>
